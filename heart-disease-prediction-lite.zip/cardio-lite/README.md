# CardioPredict (Lite) - Heart Disease Prediction System

Flask web app that estimates heart disease likelihood from 13 clinical features.
**No NumPy, pandas, scikit-learn or joblib needed.** The models are written in pure Python
(`utils/ml.py`) and saved with the standard-library `pickle`. The only dependency is Flask.

**Educational project, not a medical diagnosis.** Probabilities are not calibrated clinical risks.

## Setup
```bash
pip install flask
python train_model.py     # ~10 seconds; saves models/heart_model.pkl
python app.py             # open http://127.0.0.1:5000
```

## Using real data
`train_model.py` uses `dataset/heart.csv` if present. Put the UCI Heart Disease CSV in `dataset/`
(columns: age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal, target),
delete `dataset/DEMO_DATA.txt`, and re-run `python train_model.py`.
If no file exists, **synthetic demonstration data** is generated and the UI labels it as such.

## Method
- Stratified 80/20 train/test split. Imputation, scaling and one-hot encoding are fitted on training rows only
  (and refitted inside each cross-validation fold), so nothing leaks from the test set.
- Models: Logistic Regression (gradient descent), Random Forest (60 Gini trees), linear SVM (Pegasos + Platt scaling).
- Metrics: accuracy, precision, recall, F1, ROC AUC, confusion matrix, ROC curves, 5-fold CV AUC.
- Deployed model: Random Forest (change `DEPLOYED` in `train_model.py`).
- Caveat: hand-written models are for learning and small data. They are slower and less tuned than scikit-learn.

## Security notes
Server-side validation, CSRF token, no patient data stored, CSP headers, debug off.
Set `SECRET_KEY` in the environment for any real deployment.
