// Page scripts: probability meter, dashboard charts, performance charts.
const COLORS = ["#1d6fd6", "#1f9d6b", "#e8890c", "#d64545"];

document.querySelectorAll(".meter-fill").forEach(el => {
  requestAnimationFrame(() => { el.style.width = el.dataset.width + "%"; });
});

const make = (id, config) => { const el = document.getElementById(id); if (el) new Chart(el, config); };
const barOpts = { plugins: { legend: { display: false } }, scale: {} };

if (document.getElementById("chart-age")) {
  fetch("/api/stats").then(r => r.json()).then(s => {
    const bar = (id, h, color) => make(id, { type: "bar",
      data: { labels: h.labels, datasets: [{ data: h.counts, backgroundColor: color }] }, options: barOpts });
    bar("chart-age", s.age, COLORS[0]); bar("chart-chol", s.chol, COLORS[1]); bar("chart-bp", s.trestbps, COLORS[2]);
    make("chart-sex", { type: "doughnut", data: { labels: ["Male", "Female"],
      datasets: [{ data: [s.sex.male, s.sex.female], backgroundColor: [COLORS[0], COLORS[2]] }] } });
    make("chart-target", { type: "doughnut", data: { labels: ["No heart disease", "Heart disease"],
      datasets: [{ data: [s.negative, s.positive], backgroundColor: [COLORS[1], COLORS[3]] }] } });
  });
}

if (document.getElementById("chart-roc")) {
  fetch("/api/metrics").then(r => r.json()).then(m => {
    const sets = Object.entries(m.models).map(([name, v], i) => ({
      label: `${name} (AUC ${v.auc.toFixed(2)})`, borderColor: COLORS[i], backgroundColor: COLORS[i],
      showLine: true, pointRadius: 0, borderWidth: 2,
      data: v.roc.fpr.map((x, j) => ({ x, y: v.roc.tpr[j] })) }));
    sets.push({ label: "Chance", borderColor: "#9aa8bb", borderDash: [6, 6], showLine: true, pointRadius: 0,
      data: [{ x: 0, y: 0 }, { x: 1, y: 1 }] });
    make("chart-roc", { type: "scatter", data: { datasets: sets }, options: { scales: {
      x: { title: { display: true, text: "False positive rate" }, min: 0, max: 1 },
      y: { title: { display: true, text: "True positive rate" }, min: 0, max: 1 } } } });
  });
}
