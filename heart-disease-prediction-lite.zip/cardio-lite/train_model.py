"""Train, compare and save the heart-disease models (pure Python).   Usage: python train_model.py"""
import csv
import json
import math
import pickle
import random
from pathlib import Path

from utils import ml
from utils.preprocessing import FEATURES

BASE = Path(__file__).parent
DATA = BASE / "dataset" / "heart.csv"
DEMO_FLAG = BASE / "dataset" / "DEMO_DATA.txt"
DEPLOYED = "Random Forest"
SEED = 42


def make_demo_dataset(n=1000):
    """DEMONSTRATION DATA ONLY: synthetic records, not real patients.
    Used when dataset/heart.csv is absent. Replace it with the UCI file for real results."""
    rng = random.Random(SEED)
    clip = lambda v, lo, hi: max(lo, min(hi, v))
    pick = lambda opts, w: rng.choices(opts, weights=w)[0]
    rows = []
    for _ in range(n):
        sex = int(rng.random() < 0.68)
        age = round(clip(rng.gauss(54, 9), 29, 77))
        cp = pick([0, 1, 2, 3], [0.47, 0.17, 0.28, 0.08])
        trestbps = round(clip(rng.gauss(131 + (age - 54) * 0.4, 17), 94, 200))
        chol = round(clip(rng.gauss(246, 50), 126, 564))
        fbs = int(rng.random() < 0.15)
        restecg = pick([0, 1, 2], [0.50, 0.48, 0.02])
        thalach = round(clip(rng.gauss(205 - age * 0.9, 18), 71, 202))
        exang = int(rng.random() < 0.33)
        oldpeak = round(clip(rng.gammavariate(1.3, 0.85), 0, 6.2), 1)
        slope = pick([0, 1, 2], [0.08, 0.46, 0.46])
        ca = pick([0, 1, 2, 3], [0.58, 0.22, 0.13, 0.07])
        thal = pick([1, 2, 3], [0.06, 0.55, 0.39])
        z = (-2.6 + 0.04 * (age - 54) + 0.9 * sex + 0.6 * (cp == 0) - 0.5 * (cp == 2)
             + 0.012 * (trestbps - 131) + 0.003 * (chol - 246) - 0.035 * (thalach - 150)
             + 1.0 * exang + 0.6 * oldpeak + 0.4 * (slope == 1) + 0.8 * ca + 0.9 * (thal == 3))
        # Noise keeps the task realistic: a perfect score here would signal a leaky pipeline.
        target = int(rng.random() < ml.sigmoid(z + rng.gauss(0, 0.9)))
        row = dict(age=age, sex=sex, cp=cp, trestbps=trestbps, chol=chol, fbs=fbs, restecg=restecg,
                   thalach=thalach, exang=exang, oldpeak=oldpeak, slope=slope, ca=ca, thal=thal, target=target)
        for col in ("ca", "thal", "chol"):  # a few missing values to exercise imputation
            if rng.random() < 0.02:
                row[col] = None
        rows.append(row)
    return rows


def load_data():
    if not DATA.exists():
        print("dataset/heart.csv not found -> generating DEMONSTRATION data (synthetic).")
        DATA.parent.mkdir(exist_ok=True)
        with open(DATA, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=FEATURES + ["target"])
            w.writeheader()
            w.writerows(make_demo_dataset())
        DEMO_FLAG.write_text("dataset/heart.csv is synthetic demonstration data, not real patients.\n"
                             "Delete both files and add the UCI heart.csv to train on real data.\n")
    rows, seen = [], set()
    with open(DATA, newline="") as f:
        reader = csv.DictReader(f)
        missing = set(FEATURES + ["target"]) - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f"heart.csv is missing columns: {sorted(missing)}")
        for rec in reader:
            row = {}
            for c in FEATURES + ["target"]:
                v = (rec[c] or "").strip()
                row[c] = None if v in ("", "?", "NA", "nan") else float(v)
            row["target"] = 1 if (row["target"] or 0) > 0 else 0  # UCI 'num' 1-4 -> 1
            key = tuple(row.values())
            if key not in seen:  # drop exact duplicate rows
                seen.add(key)
                rows.append(row)
    return rows


def histogram(values, bins):
    values = [v for v in values if v is not None]
    lo, hi = min(values), max(values)
    width = (hi - lo) / bins or 1
    counts = [0] * bins
    for v in values:
        counts[min(bins - 1, int((v - lo) / width))] += 1
    return {"labels": [f"{int(lo + i * width)}-{int(lo + (i + 1) * width)}" for i in range(bins)], "counts": counts}


def factories():
    return {
        "Logistic Regression": lambda: ml.Model(ml.LogisticRegression()),
        "Random Forest": lambda: ml.Model(ml.RandomForest()),
        "SVM": lambda: ml.Model(ml.LinearSVM()),
    }


def main():
    data = load_data()
    rows = [{c: r[c] for c in FEATURES} for r in data]
    y = [r["target"] for r in data]
    tr, te = ml.stratified_split(y, 0.2, SEED)
    X_tr, y_tr = [rows[i] for i in tr], [y[i] for i in tr]
    X_te, y_te = [rows[i] for i in te], [y[i] for i in te]

    results, fitted = {}, {}
    for name, make in factories().items():
        # 5-fold CV on TRAINING rows only; every fold fits its own preprocessing.
        aucs = []
        for fold in ml.stratified_folds(y_tr, 5, SEED):
            held = set(fold)
            a = [i for i in range(len(y_tr)) if i not in held]
            m = make().fit([X_tr[i] for i in a], [y_tr[i] for i in a])
            aucs.append(ml.roc_auc([y_tr[i] for i in fold], m.predict_proba_rows([X_tr[i] for i in fold])))
        model = make().fit(X_tr, y_tr)
        prob = model.predict_proba_rows(X_te)
        pred = [int(p >= 0.5) for p in prob]
        (tn, fp), (fn, tp) = ml.confusion(y_te, pred)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        fpr, tpr = ml.roc_curve(y_te, prob)
        results[name] = dict(
            accuracy=(tp + tn) / len(y_te), precision=precision, recall=recall,
            f1=2 * precision * recall / (precision + recall) if precision + recall else 0.0,
            auc=ml.roc_auc(y_te, prob), cv_auc=sum(aucs) / len(aucs),
            confusion=[[tn, fp], [fn, tp]], roc=dict(fpr=fpr, tpr=tpr))
        fitted[name] = model
        print(f"{name:20s} acc={results[name]['accuracy']:.3f} f1={results[name]['f1']:.3f} "
              f"auc={results[name]['auc']:.3f}")

    (BASE / "models").mkdir(exist_ok=True)
    with open(BASE / "models" / "heart_model.pkl", "wb") as f:
        pickle.dump(fitted[DEPLOYED], f)
    demo = DEMO_FLAG.exists()
    (BASE / "models" / "metrics.json").write_text(json.dumps(
        dict(models=results, deployed=DEPLOYED, n_train=len(y_tr), n_test=len(y_te), demo_data=demo)))
    male = [r for r in data if r["sex"] == 1]
    female = [r for r in data if r["sex"] == 0]
    (BASE / "models" / "stats.json").write_text(json.dumps(dict(
        total=len(data), positive=sum(y), negative=len(y) - sum(y), demo_data=demo,
        sex=dict(male=len(male), female=len(female)),
        disease_by_sex=dict(male=sum(r["target"] for r in male), female=sum(r["target"] for r in female)),
        age=histogram([r["age"] for r in data], 8), chol=histogram([r["chol"] for r in data], 8),
        trestbps=histogram([r["trestbps"] for r in data], 8))))
    print(f"Saved models/heart_model.pkl ({DEPLOYED}). Test rows: {len(y_te)}.")


if __name__ == "__main__":
    main()
