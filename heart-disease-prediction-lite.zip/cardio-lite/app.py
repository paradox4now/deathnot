"""CardioPredict - Flask app. Run: python app.py  ->  http://127.0.0.1:5000"""
import json
import os
import secrets
from pathlib import Path

import pickle
from flask import Flask, abort, jsonify, render_template, request, session

from utils.preprocessing import FIELDS, validate_input

BASE = Path(__file__).parent
app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),  # set SECRET_KEY in production
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=16 * 1024,  # forms are tiny; reject anything larger
)

_model = None


def get_model():
    global _model
    if _model is None:
        path = BASE / "models" / "heart_model.pkl"
        if not path.exists():
            return None
        with open(path, "rb") as f:
            _model = pickle.load(f)
    return _model


def load_json(name):
    path = BASE / "models" / name
    return json.loads(path.read_text()) if path.exists() else None


def risk_band(p):
    if p < 0.30:
        return "Lower", "low"
    if p < 0.60:
        return "Moderate", "mid"
    return "Higher", "high"


@app.context_processor
def inject_globals():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return dict(csrf_token=session["csrf"])


@app.after_request
def security_headers(resp):
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; img-src 'self' data:")
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Cache-Control"] = "no-store" if request.path == "/predict" else "no-cache"
    return resp


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/predict", methods=["GET", "POST"])
def predict():
    ctx = dict(fields=FIELDS, form={}, errors={}, result=None, error_banner=None)
    if request.method == "POST":
        if request.form.get("csrf") != session.get("csrf"):
            abort(400, "Invalid form token. Reload the page and try again.")
        values, errors = validate_input(request.form)
        ctx.update(form=request.form, errors=errors)
        model = get_model()
        if model is None:
            ctx["error_banner"] = "No trained model found. Run `python train_model.py` first."
        elif not errors:
            prob = float(model.predict_proba(values))  # nothing is stored
            label, css = risk_band(prob)
            summary = [(f["label"], dict(f.get("options", [])).get(int(values[f["name"]]), values[f["name"]])
                        if f["type"] == "select" else f"{values[f['name']]:g} {f['unit']}") for f in FIELDS]
            ctx["result"] = dict(prob=round(prob * 100, 1), positive=prob >= 0.5, band=label, css=css,
                                 summary=summary)
    return render_template("predict.html", **ctx)


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", stats=load_json("stats.json"))


@app.route("/performance")
def performance():
    return render_template("performance.html", metrics=load_json("metrics.json"))


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/api/stats")
def api_stats():
    return jsonify(load_json("stats.json") or {})


@app.route("/api/metrics")
def api_metrics():
    return jsonify(load_json("metrics.json") or {})


@app.errorhandler(400)
@app.errorhandler(404)
def handle_error(e):
    return render_template("error.html", code=e.code, message=e.description), e.code


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
