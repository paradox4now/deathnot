"""Shared feature definitions and input validation (used by training AND the web app). Pure Python."""
NUMERIC = ["age", "trestbps", "chol", "thalach", "oldpeak"]
CATEGORICAL = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]
FEATURES = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
            "thalach", "exang", "oldpeak", "slope", "ca", "thal"]

# Form definition: drives the HTML form AND backend validation, so they cannot drift apart.
FIELDS = [
    dict(name="age", label="Age", type="number", min=18, max=100, step=1, unit="years", help="Age in years."),
    dict(name="sex", label="Sex", type="select", options=[(1, "Male"), (0, "Female")],
         help="Biological sex as recorded in the dataset."),
    dict(name="cp", label="Chest pain type", type="select",
         options=[(0, "Typical angina"), (1, "Atypical angina"), (2, "Non-anginal pain"), (3, "Asymptomatic")],
         help="Type of chest pain the patient reports."),
    dict(name="trestbps", label="Resting blood pressure", type="number", min=80, max=220, step=1, unit="mm Hg",
         help="Systolic blood pressure at rest."),
    dict(name="chol", label="Serum cholesterol", type="number", min=100, max=600, step=1, unit="mg/dl",
         help="Total serum cholesterol."),
    dict(name="fbs", label="Fasting blood sugar", type="select",
         options=[(0, "120 mg/dl or lower"), (1, "Above 120 mg/dl")], help="Blood sugar after fasting."),
    dict(name="restecg", label="Resting ECG", type="select",
         options=[(0, "Normal"), (1, "ST-T wave abnormality"), (2, "Left ventricular hypertrophy")],
         help="Result of the resting electrocardiogram."),
    dict(name="thalach", label="Maximum heart rate", type="number", min=60, max=220, step=1, unit="bpm",
         help="Highest heart rate reached during the exercise test."),
    dict(name="exang", label="Exercise-induced angina", type="select", options=[(0, "No"), (1, "Yes")],
         help="Whether exercise triggered chest pain."),
    dict(name="oldpeak", label="ST depression (oldpeak)", type="number", min=0, max=7, step=0.1, unit="mm",
         help="ST segment depression during exercise compared with rest."),
    dict(name="slope", label="ST slope", type="select",
         options=[(0, "Upsloping"), (1, "Flat"), (2, "Downsloping")],
         help="Slope of the peak-exercise ST segment."),
    dict(name="ca", label="Major vessels colored by fluoroscopy", type="select",
         options=[(0, "0"), (1, "1"), (2, "2"), (3, "3")], help="Number of major vessels (0-3) with visible blockage."),
    dict(name="thal", label="Thalassemia", type="select",
         options=[(1, "Normal"), (2, "Fixed defect"), (3, "Reversible defect")],
         help="Result of the thallium stress test."),
]


def validate_input(form):
    """Validate raw form data. Returns (clean_values, errors). Never trusts the browser."""
    values, errors = {}, {}
    for f in FIELDS:
        raw = (form.get(f["name"]) or "").strip()
        if raw == "":
            errors[f["name"]] = f"{f['label']} is required."
            continue
        try:
            num = float(raw)
        except ValueError:
            errors[f["name"]] = f"{f['label']} must be a number."
            continue
        if num != num or num in (float("inf"), float("-inf")):  # reject nan / inf
            errors[f["name"]] = f"{f['label']} must be a real number."
        elif f["type"] == "number" and not (f["min"] <= num <= f["max"]):
            errors[f["name"]] = f"{f['label']} must be between {f['min']} and {f['max']}."
        elif f["type"] == "select" and num not in [float(v) for v, _ in f["options"]]:
            errors[f["name"]] = f"Choose one of the listed options for {f['label']}."
        else:
            values[f["name"]] = num
    return values, errors
