"""Machine learning from scratch with only the Python standard library (no NumPy, scikit-learn, pandas)."""
import math
import random
from statistics import median

from utils.preprocessing import CATEGORICAL, NUMERIC


def sigmoid(z):
    if z >= 0:
        return 1 / (1 + math.exp(-z))
    e = math.exp(z)
    return e / (1 + e)


class Preprocessor:
    """Median/mode imputation, standard scaling, one-hot encoding. Fitted on training rows only."""

    def fit(self, rows):
        self.stats, self.cats = {}, {}
        for c in NUMERIC:
            vals = [r[c] for r in rows if r[c] is not None]
            med = median(vals)
            mean = sum(vals) / len(vals)
            std = math.sqrt(sum((v - mean) ** 2 for v in vals) / len(vals)) or 1.0
            self.stats[c] = (med, mean, std)
        for c in CATEGORICAL:
            vals = [r[c] for r in rows if r[c] is not None]
            self.cats[c] = (max(set(vals), key=vals.count), sorted(set(vals)))  # (mode, categories)
        return self

    def transform_row(self, r):
        out = []
        for c in NUMERIC:
            med, mean, std = self.stats[c]
            v = med if r[c] is None else r[c]
            out.append((v - mean) / std)
        for c in CATEGORICAL:
            mode, cats = self.cats[c]
            v = mode if r[c] is None else r[c]
            out.extend(1.0 if v == k else 0.0 for k in cats)  # unseen category -> all zeros
        return out


class LogisticRegression:
    def __init__(self, epochs=250, lr=0.3, l2=0.01):
        self.epochs, self.lr, self.l2 = epochs, lr, l2

    def fit(self, X, y):
        n, d = len(X), len(X[0])
        w, b = [0.0] * d, 0.0
        for _ in range(self.epochs):
            gw, gb = [0.0] * d, 0.0
            for xi, yi in zip(X, y):
                err = sigmoid(sum(wj * xj for wj, xj in zip(w, xi)) + b) - yi
                gb += err
                for j in range(d):
                    gw[j] += err * xi[j]
            w = [wj - self.lr * (g / n + self.l2 * wj) for wj, g in zip(w, gw)]
            b -= self.lr * gb / n
        self.w, self.b = w, b
        return self

    def predict_proba(self, x):
        return sigmoid(sum(wj * xj for wj, xj in zip(self.w, x)) + self.b)


class LinearSVM:
    """Linear SVM trained with Pegasos (hinge-loss SGD); Platt scaling turns scores into probabilities."""

    def __init__(self, epochs=40, lam=0.01, seed=42):
        self.epochs, self.lam, self.seed = epochs, lam, seed

    def _score(self, x):
        return sum(wj * xj for wj, xj in zip(self.w, x)) + self.b

    def fit(self, X, y):
        rng, d = random.Random(self.seed), len(X[0])
        self.w, self.b, t = [0.0] * d, 0.0, 0
        for _ in range(self.epochs):
            order = list(range(len(X)))
            rng.shuffle(order)
            for i in order:
                t += 1
                eta = 1.0 / (self.lam * (t + 100))
                s = 2 * y[i] - 1
                margin = s * self._score(X[i])
                shrink = 1 - eta * self.lam
                self.w = [wj * shrink for wj in self.w]
                if margin < 1:
                    self.w = [wj + eta * s * xj for wj, xj in zip(self.w, X[i])]
                    self.b += eta * s * 0.1
        scores = [self._score(x) for x in X]  # Platt scaling: p = sigmoid(a*score + c)
        self.a, self.c = 1.0, 0.0
        for _ in range(300):
            ga = gc = 0.0
            for s, yi in zip(scores, y):
                err = sigmoid(self.a * s + self.c) - yi
                ga += err * s
                gc += err
            self.a -= 0.5 * ga / len(y)
            self.c -= 0.5 * gc / len(y)
        return self

    def predict_proba(self, x):
        return sigmoid(self.a * self._score(x) + self.c)


class DecisionTree:
    def __init__(self, max_depth, min_leaf, mtry, rng):
        self.max_depth, self.min_leaf, self.mtry, self.rng = max_depth, min_leaf, mtry, rng

    def fit(self, X, y):
        self.root = self._build(list(range(len(X))), X, y, 0)
        return self

    def _build(self, idx, X, y, depth):
        n, pos = len(idx), sum(y[i] for i in idx)
        leaf = ("leaf", pos / n)
        if depth >= self.max_depth or n < 2 * self.min_leaf or pos in (0, n):
            return leaf
        best = None  # (weighted gini, feature, threshold)
        for f in self.rng.sample(range(len(X[0])), self.mtry):
            order = sorted(idx, key=lambda i: X[i][f])
            left_pos = 0
            for k in range(n - 1):
                left_pos += y[order[k]]
                a, b = X[order[k]][f], X[order[k + 1]][f]
                nl, nr = k + 1, n - k - 1
                if a == b or nl < self.min_leaf or nr < self.min_leaf:
                    continue
                pl, pr = left_pos / nl, (pos - left_pos) / nr
                score = nl * pl * (1 - pl) + nr * pr * (1 - pr)
                if best is None or score < best[0]:
                    best = (score, f, (a + b) / 2)
        if best is None:
            return leaf
        _, f, thr = best
        left = [i for i in idx if X[i][f] <= thr]
        right = [i for i in idx if X[i][f] > thr]
        return ("split", f, thr, self._build(left, X, y, depth + 1), self._build(right, X, y, depth + 1))

    def predict_proba(self, x):
        node = self.root
        while node[0] == "split":
            node = node[3] if x[node[1]] <= node[2] else node[4]
        return node[1]


class RandomForest:
    def __init__(self, n_trees=60, max_depth=8, min_leaf=3, seed=42):
        self.n_trees, self.max_depth, self.min_leaf, self.seed = n_trees, max_depth, min_leaf, seed

    def fit(self, X, y):
        rng, n = random.Random(self.seed), len(X)
        mtry = max(1, int(math.sqrt(len(X[0]))))
        self.trees = []
        for _ in range(self.n_trees):
            sample = [rng.randrange(n) for _ in range(n)]  # bootstrap
            Xb, yb = [X[i] for i in sample], [y[i] for i in sample]
            self.trees.append(DecisionTree(self.max_depth, self.min_leaf, mtry, rng).fit(Xb, yb))
        return self

    def predict_proba(self, x):
        return sum(t.predict_proba(x) for t in self.trees) / len(self.trees)


class Model:
    """Preprocessor + classifier. This whole object is what gets pickled."""

    def __init__(self, clf):
        self.clf, self.pre = clf, Preprocessor()

    def fit(self, rows, y):
        self.pre.fit(rows)
        self.clf.fit([self.pre.transform_row(r) for r in rows], y)
        return self

    def predict_proba_rows(self, rows):
        return [self.clf.predict_proba(self.pre.transform_row(r)) for r in rows]

    def predict_proba(self, row):
        return self.predict_proba_rows([row])[0]


# ---------- evaluation helpers ----------
def stratified_split(y, test_size, seed):
    rng, train, test = random.Random(seed), [], []
    for cls in (0, 1):
        idx = [i for i, v in enumerate(y) if v == cls]
        rng.shuffle(idx)
        k = round(len(idx) * test_size)
        test += idx[:k]
        train += idx[k:]
    return sorted(train), sorted(test)


def stratified_folds(y, k, seed):
    rng, folds = random.Random(seed), [[] for _ in range(k)]
    for cls in (0, 1):
        idx = [i for i, v in enumerate(y) if v == cls]
        rng.shuffle(idx)
        for j, i in enumerate(idx):
            folds[j % k].append(i)
    return folds


def confusion(y, pred):
    tn = sum(1 for a, p in zip(y, pred) if a == 0 and p == 0)
    fp = sum(1 for a, p in zip(y, pred) if a == 0 and p == 1)
    fn = sum(1 for a, p in zip(y, pred) if a == 1 and p == 0)
    tp = sum(1 for a, p in zip(y, pred) if a == 1 and p == 1)
    return [[tn, fp], [fn, tp]]


def roc_auc(y, scores):
    """AUC via the rank-sum (Mann-Whitney) formula, with tied scores sharing average rank."""
    order = sorted(range(len(y)), key=lambda i: scores[i])
    ranks, i = [0.0] * len(y), 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and scores[order[j + 1]] == scores[order[i]]:
            j += 1
        for k in range(i, j + 1):
            ranks[order[k]] = (i + j) / 2 + 1
        i = j + 1
    n1 = sum(y)
    n0 = len(y) - n1
    return (sum(r for r, v in zip(ranks, y) if v == 1) - n1 * (n1 + 1) / 2) / (n1 * n0)


def roc_curve(y, scores, max_points=120):
    n1, n0 = sum(y), len(y) - sum(y)
    order = sorted(range(len(y)), key=lambda i: -scores[i])
    fpr, tpr, tp, fp = [0.0], [0.0], 0, 0
    for k, i in enumerate(order):
        tp += y[i]
        fp += 1 - y[i]
        if k + 1 == len(order) or scores[order[k + 1]] != scores[i]:
            fpr.append(fp / n0)
            tpr.append(tp / n1)
    step = max(1, len(fpr) // max_points)
    keep = list(range(0, len(fpr), step)) + ([len(fpr) - 1] if (len(fpr) - 1) % step else [])
    return [round(fpr[i], 3) for i in keep], [round(tpr[i], 3) for i in keep]
